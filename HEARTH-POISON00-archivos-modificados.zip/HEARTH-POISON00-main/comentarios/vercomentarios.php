<?php
$archivo=__DIR__.'/comentario.txt';
$contenido=file_exists($archivo)?file_get_contents($archivo):'Aún no hay comentarios.';
?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Comentarios</title>
<style>body{background:#080808;color:#fff;font-family:Arial;margin:0}.box{max-width:800px;margin:140px auto;padding:30px;background:#111;border:1px solid #292929;border-radius:18px}h1{text-align:center;font-weight:300;letter-spacing:4px}.coment{white-space:pre-wrap;background:#090909;border:1px solid #222;border-radius:10px;padding:18px;margin:12px 0;color:#ddd}.btn{display:inline-block;margin-top:18px;padding:11px 18px;background:#fff;color:#000;text-decoration:none;border-radius:8px;font-weight:bold}</style></head><body>
<?php include '../header.php'; ?><div class="box"><h1>Comentarios</h1><div class="coment"><?=htmlspecialchars($contenido,ENT_QUOTES,'UTF-8')?></div><a class="btn" href="../comentarios.php">Nuevo comentario</a></div></body></html>