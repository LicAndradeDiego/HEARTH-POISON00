<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ../comentarios.php'); exit; }
$nom=trim($_POST['nom']??''); $asu=trim($_POST['asu']??''); $come=trim($_POST['com']??'');
if($nom===''||$asu===''||$come===''){ header('Location: ../comentarios.php?error=campos'); exit; }
$archivo=fopen(__DIR__.'/comentario.txt','a');
if(!$archivo){ die('No se pudo guardar el comentario.'); }
fwrite($archivo, "NOMBRE: ".str_replace(["\r","\n"],' ',$nom).PHP_EOL);
fwrite($archivo, "ASUNTO: ".str_replace(["\r","\n"],' ',$asu).PHP_EOL);
fwrite($archivo, "COMENTARIO: ".str_replace(["\r","\n"],' ',$come).PHP_EOL);
fwrite($archivo, "FECHA: ".date('Y-m-d H:i:s').PHP_EOL);
fwrite($archivo, str_repeat('-',60).PHP_EOL);
fclose($archivo);
?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script></head>
<body style="background:#080808"><script>
Swal.fire({icon:'success',title:'¡Comentario enviado!',text:'Gracias por tu sugerencia.',confirmButtonText:'Continuar',confirmButtonColor:'#7a2735',background:'#111',color:'#fff'}).then(()=>location.href='../comentarios.php');
</script></body></html>