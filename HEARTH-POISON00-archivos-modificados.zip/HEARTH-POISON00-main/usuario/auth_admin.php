<?php
// Protección centralizada para funciones administrativas.
if (session_status() === PHP_SESSION_NONE) { session_start(); }

$rolSesion = strtolower(trim($_SESSION['rol'] ?? $_SESSION['Rol'] ?? ''));
if (!isset($_SESSION['nombre']) || $rolSesion !== 'administrador') {
    header('Location: /HEARTH-POISON00/usuario/paginasesion.php?error=sin_permiso');
    exit();
}
$_SESSION['rol'] = $rolSesion;
?>
