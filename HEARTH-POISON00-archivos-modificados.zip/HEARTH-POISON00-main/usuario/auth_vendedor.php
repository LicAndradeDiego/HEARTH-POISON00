<?php
// Protección centralizada para funciones del vendedor.
if (session_status() === PHP_SESSION_NONE) { session_start(); }

$rolSesion = strtolower(trim($_SESSION['rol'] ?? $_SESSION['Rol'] ?? ''));
if (!isset($_SESSION['nombre']) || !in_array($rolSesion, ['administrador','vendedor'], true)) {
    header('Location: /HEARTH-POISON00/usuario/paginasesion.php?error=sin_permiso');
    exit();
}
$_SESSION['rol'] = $rolSesion;
?>
