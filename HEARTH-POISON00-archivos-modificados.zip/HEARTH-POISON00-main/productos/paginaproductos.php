<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catálogo | HEARTH POISON</title>
    <link rel="stylesheet" href="urielgood.css">
    <style>
        *{
            text-decoration:none;
        }
    </style>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

  <?php include '../header.php'; ?>

    <main>
        <section class="animate-fade">
            <h2 class="section-title">El Catálogo</h2>
        <a href="productosinfo/acqua.php">
            <div class="cards-grid">
                <div class="product-card">
                    <div class="img-container">
                        <img src="https://images.unsplash.com/photo-1541643600914-78b084683601?q=80&w=600&auto=format&fit=crop" alt="Acqua Di Gio">
                    </div>
                    <div class="product-info">
                        <div class="brand">Giorgio Armani</div>
                        <h3>Acqua Di Gio</h3>
                        <div class="precio">Bs. 550</div>
                        <button class="btn-add" onclick="window.location.href='carrito/miCarrito.php'">Añadir al Carrito</button>
                    </div>
                </div>
                </a>
                <a href="productosinfo/eros.php">
                <div class="product-card">
                    <div class="img-container">
                        <img src="https://images.unsplash.com/photo-1594035910387-fea47794261f?q=80&w=600&auto=format&fit=crop" alt="Versace Eros">
                    </div>
                    <div class="product-info">
                        <div class="brand">Versace</div>
                        <h3>Versace Eros</h3>
                        <div class="precio">Bs. 650</div>
                        <button class="btn-add" onclick="window.location.href='carrito/miCarrito.php'">Añadir al Carrito</button>
                    </div>
                </div>
                </a>
                <a href="productosinfo/paradise.php">
                <div class="product-card">
                    <div class="img-container">
                        <img src="https://images.unsplash.com/photo-1523293182086-7651a899d37f?q=80&w=600&auto=format&fit=crop" alt="Le Beau">
                    </div>
                    <div class="product-info">
                        <div class="brand">Jean Paul Gaultier</div>
                        <h3>Le Beau Paradise</h3>
                        <div class="precio">Bs. 700</div>
                        <button class="btn-add" onclick="window.location.href='carrito/miCarrito.php'">Añadir al Carrito</button>
                    </div>
                </div>
                </a>
                <a href="productosinfo/bleu.php">
                <div class="product-card">
                    <div class="img-container">
                        <img src="https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?q=80&w=600&auto=format&fit=crop" alt="Bleu de Chanel">
                    </div>
                    <div class="product-info">
                        <div class="brand">Chanel</div>
                        <h3>Bleu De Chanel</h3>
                        <div class="precio">Bs. 980</div>
                        <button class="btn-add" onclick="window.location.href='carrito/miCarrito.php'">Añadir al Carrito</button>
                    </div>
                </div>
                </a>
                <a href="productosinfo/noir.php">
                <div class="product-card">
                    <div class="img-container">
                        <img src="https://images.unsplash.com/photo-1616949755610-8c9bbc08f138?q=80&w=600&auto=format&fit=crop" alt="Noir Extreme">
                    </div>
                    <div class="product-info">
                        <div class="brand">Tom Ford</div>
                        <h3>Noir Extreme</h3>
                        <div class="precio">Bs. 1,200</div>
                        <button class="btn-add" onclick="window.location.href='carrito/miCarrito.php'">Añadir al Carrito</button>
                    </div>
                </div>
                </a>
                <a href="productosinfo/sauvage.php">
                <div class="product-card">
                    <div class="img-container">
                        <img src="https://images.unsplash.com/photo-1594035910387-fea47794261f?q=80&w=600&auto=format&fit=crop" alt="Sauvage">
                    </div>
                    <div class="product-info">
                        <div class="brand">Dior</div>
                        <h3>Sauvage Elixir</h3>
                        <div class="precio">Bs. 1,100</div>
                        <button class="btn-add" onclick="window.location.href='carrito/miCarrito.php'">Añadir al Carrito</button>
                    </div>
                </div>
                </a>
                <a href="productosinfo/oud.php">
                <div class="product-card">
                    <div class="img-container">
                        <img src="https://images.unsplash.com/photo-1541643600914-78b084683601?q=80&w=600&auto=format&fit=crop" alt="Oud Wood">
                    </div>
                    <div class="product-info">
                        <div class="brand">Tom Ford</div>
                        <h3>Oud Wood Privée</h3>
                        <div class="precio">Bs. 1,800</div>
                        <button class="btn-add" onclick="window.location.href='carrito/miCarrito.php'">Añadir al Carrito</button>
                    </div>
                </div>
                </a>
                <a href="productosinfo/aventus.php">
                <div class="product-card">
                    <div class="img-container">
                        <img src="https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?q=80&w=600&auto=format&fit=crop" alt="Creed Aventus">
                    </div>
                    <div class="product-info">
                        <div class="brand">Creed</div>
                        <h3>Aventus Heritage</h3>
                        <div class="precio">Bs. 2,100</div>
                        <button class="btn-add" onclick="window.location.href='carrito/miCarrito.php'">Añadir al Carrito</button>
                    </div>
                </div>
                </a>
                <a href="productosinfo/libre.php">
                <div class="product-card">
                    <div class="img-container">
                        <img src="https://images.unsplash.com/photo-1616949755610-8c9bbc08f138?q=80&w=600&auto=format&fit=crop" alt="Libre">
                    </div>
                    <div class="product-info">
                        <div class="brand">Yves Saint Laurent</div>
                        <h3>Libre Intense</h3>
                        <div class="precio">Bs. 890</div>
                        <button class="btn-add" onclick="window.location.href='carrito/miCarrito.php'">Añadir al Carrito</button>
                    </div>
                </div>
                </a>
                <a href="productosinfo/interlude.php">
                <div class="product-card">
                    <div class="img-container">
                        <img src="https://images.unsplash.com/photo-1594035910387-fea47794261f?q=80&w=600&auto=format&fit=crop" alt="Interlude">
                    </div>
                    <div class="product-info">
                        <div class="brand">Amouage</div>
                        <h3>Interlude Man</h3>
                        <div class="precio">Bs. 1,950</div>
                        <button class="btn-add" onclick="window.location.href='carrito/miCarrito.php'">Añadir al Carrito</button>
                    </div>
                </div>
                 </a>
                 <a href="productosinfo/rouge.php">
                <div class="product-card">
                    <div class="img-container">
                        <img src="https://images.unsplash.com/photo-1541643600914-78b084683601?q=80&w=600&auto=format&fit=crop" alt="Baccarat">
                    </div>
                    <div class="product-info">
                        <div class="brand">Maison Francis</div>
                        <h3>Baccarat Rouge 540</h3>
                        <div class="precio">Bs. 2,400</div>
                        <button class="btn-add" onclick="window.location.href='carrito/miCarrito.php'">Añadir al Carrito</button>
                    </div>
                </div>
                </a>
                 <a href="productosinfo/light.php">
                <div class="product-card">
                    <div class="img-container">
                        <img src="https://images.unsplash.com/photo-1523293182086-7651a899d37f?q=80&w=600&auto=format&fit=crop" alt="Light Blue">
                    </div>
                    <div class="product-info">
                        <div class="brand">Dolce & Gabbana</div>
                        <h3>Light Blue Forever</h3>
                        <div class="precio">Bs. 680</div>
                        <button class="btn-add" onclick="window.location.href='carrito/miCarrito.php'">Añadir al Carrito</button>
                    </div>
                </div>
                </a>
               
            </div>
        </section>

        <section class="animate-fade" style="margin-top:70px;">
            <h2 class="section-title">Estado de mi pedido</h2>
            <div style="max-width:620px;margin:0 auto;background:#111;border:1px solid #292929;border-radius:18px;padding:28px;text-align:center;">
                <p style="color:#aaa;margin-bottom:18px;">Ingresa el número de pedido para consultar su estado.</p>
                <form id="formSeguimientoLegacy" style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
                    <input type="number" id="pedidoLegacy" min="1" required placeholder="N.º de pedido" style="flex:1;min-width:220px;padding:13px;border-radius:8px;border:1px solid #333;background:#090909;color:#fff;">
                    <button type="submit" class="btn-add">Ver estado</button>
                </form>
                <div id="resultadoLegacy" style="margin-top:20px;"></div>
            </div>
        </section>

    </main>


<script>
document.getElementById('formSeguimientoLegacy').addEventListener('submit',async e=>{
 e.preventDefault();const fd=new FormData();fd.append('id',document.getElementById('pedidoLegacy').value);
 try{const r=await fetch('../paginasproductos/consultar_pedido.php',{method:'POST',body:fd});const d=await r.json();
 document.getElementById('resultadoLegacy').innerHTML=d.ok?'<strong>Pedido #'+d.pedido.id+'</strong><br>Estado: '+d.pedido.estado:'<span style="color:#ff7070">'+d.mensaje+'</span>';
 if(window.Swal)Swal.fire({icon:d.ok?'success':'error',title:d.ok?'Pedido encontrado':'No encontrado',text:d.ok?('Estado: '+d.pedido.estado):d.mensaje,confirmButtonColor:'#7a2735',background:'#111',color:'#fff'});
 }catch(x){}
});
</script>

    <?php include '../footer.php'; ?>
    <script src="../../carrito/carrito.js"></script>

</body>
</html>