<?php
require("conexion.php");
header("Content-Type: application/json; charset=utf-8");

$id = filter_input(INPUT_POST, "id", FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    echo json_encode(["ok"=>false, "mensaje"=>"Ingresa un número de pedido válido."]);
    exit;
}

$stmt = $conn->prepare("SELECT id, nombre, fecha, estado, nombre_vendedor FROM pedidos WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    echo json_encode(["ok"=>false, "mensaje"=>"No encontramos ese pedido. Verifica el número."]);
    exit;
}
$pedido = $res->fetch_assoc();
echo json_encode(["ok"=>true, "pedido"=>$pedido], JSON_UNESCAPED_UNICODE);
$stmt->close();
$conn->close();
?>
